# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'signpage.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3
import re
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_signpage(object):
    ########################
    def showMessageBox1(self,title,message):
        msgBox = QtGui.QMessageBox()
        msgBox.setIcon(QtGui.QMessageBox.Warning)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtGui.QMessageBox.Ok)
        msgBox.exec_()
    ###########################
    ########################
    def loginCheck1(self):
        password =self.plineEdit.text()
        password1=self.resiglineedit.text()
        z=self.mlineedit.text()
        z1=self.ulineEdit.text()
        z2=self.elineEdit.text()
        match = re.match('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$', z2)
        z3=self.flineedit.text()
        z4=self.llineedit.text()
        if(password==password1):
            ###############
            if(len(z)==10):
                #################
                    if(len(z1)==0):
                        print("user id is not correct")
                        self.showMessageBox1('Warning','enter valid user id')
                    ###########
                    else:
                        print("user id is correct")
                        if(match == None):
                            self.showMessageBox1('Warning','enter valid Email id')
                        else:
                            if(len(z3)==0):
                                self.showMessageBox1('Warning','enter valid First name')
                            else:
                                if(len(z4)==0):
                                    self.showMessageBox1('Warning','enter valid last name')
                                else:
                                    self.insertData()
                ###########
            
                  #############
            else:
                self.showMessageBox1('Warning','Mobile No is not correct')
                
            print("correct password! ")
            ###########
        else:
           
            print("password is not match !")
            self.showMessageBox1('Warning','password is not match')

    ########################
    
 ################################################################
    def insertData(self):
            fname = self.flineedit.text()
            lname = self.llineedit.text()
            email = self.elineEdit.text()
            userid=self.ulineEdit.text()
            contact=self.mlineedit.text()
            password = self.plineEdit.text()
            cpassword=self.resiglineedit.text()

            connection  = sqlite3.connect("sign.db")
            connection.execute("INSERT INTO trial VALUES(?,?,?,?,?,?,?)",(fname,lname,contact,email,userid,password,cpassword))
            connection.commit()
            connection.close()
            self.flineedit.clear()
            self.llineedit.clear()
            self.mlineedit.clear()
            self.elineEdit.clear()
            self.ulineEdit.clear()
            self.plineEdit.clear()
            self.resiglineedit.clear()
            
    #####################################
    def setupUi(self, signpage):
        signpage.setObjectName(_fromUtf8("signpage"))
        signpage.resize(694, 559)
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        signpage.setFont(font)
        self.name = QtGui.QLabel(signpage)
        self.name.setGeometry(QtCore.QRect(60, 60, 51, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.name.setFont(font)
        self.name.setObjectName(_fromUtf8("name"))
        self.flineedit = QtGui.QLineEdit(signpage)
        self.flineedit.setGeometry(QtCore.QRect(130, 70, 181, 20))
        self.flineedit.setObjectName(_fromUtf8("flineedit"))
        self.llineedit = QtGui.QLineEdit(signpage)
        self.llineedit.setGeometry(QtCore.QRect(320, 70, 181, 20))
        self.llineedit.setObjectName(_fromUtf8("llineedit"))
        self.fname = QtGui.QLabel(signpage)
        self.fname.setGeometry(QtCore.QRect(150, 35, 81, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.fname.setFont(font)
        self.fname.setObjectName(_fromUtf8("fname"))
        self.lname = QtGui.QLabel(signpage)
        self.lname.setGeometry(QtCore.QRect(350, 30, 81, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.lname.setFont(font)
        self.lname.setObjectName(_fromUtf8("lname"))
        self.mobileno = QtGui.QLabel(signpage)
        self.mobileno.setGeometry(QtCore.QRect(30, 130, 81, 20))
        self.mobileno.setObjectName(_fromUtf8("mobileno"))
        self.mlineedit = QtGui.QLineEdit(signpage)
        self.mlineedit.setGeometry(QtCore.QRect(130, 130, 201, 20))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.mlineedit.setFont(font)
        self.mlineedit.setObjectName(_fromUtf8("mlineedit"))
        self.emailid = QtGui.QLabel(signpage)
        self.emailid.setGeometry(QtCore.QRect(30, 190, 71, 16))
        self.emailid.setObjectName(_fromUtf8("emailid"))
        self.elineEdit = QtGui.QLineEdit(signpage)
        self.elineEdit.setGeometry(QtCore.QRect(130, 190, 401, 21))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.elineEdit.setFont(font)
        self.elineEdit.setObjectName(_fromUtf8("elineEdit"))
        self.userid = QtGui.QLabel(signpage)
        self.userid.setGeometry(QtCore.QRect(30, 250, 71, 16))
        self.userid.setObjectName(_fromUtf8("userid"))
        self.ulineEdit = QtGui.QLineEdit(signpage)
        self.ulineEdit.setGeometry(QtCore.QRect(130, 250, 201, 20))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.ulineEdit.setFont(font)
        self.ulineEdit.setObjectName(_fromUtf8("ulineEdit"))
        self.password2 = QtGui.QLabel(signpage)
        self.password2.setGeometry(QtCore.QRect(30, 300, 71, 16))
        self.password2.setObjectName(_fromUtf8("password2"))
        self.plineEdit = QtGui.QLineEdit(signpage)
        self.plineEdit.setGeometry(QtCore.QRect(130, 300, 201, 20))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.plineEdit.setFont(font)
        self.plineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.plineEdit.setObjectName(_fromUtf8("plineEdit"))
        self.signin2 = QtGui.QPushButton(signpage)
        self.signin2.setGeometry(QtCore.QRect(260, 420, 121, 31))
        self.signin2.setObjectName(_fromUtf8("signin2"))
        #############################
        self.signin2.clicked.connect(self.loginCheck1)
        ############################
        self.repasswordsign = QtGui.QLabel(signpage)
        self.repasswordsign.setGeometry(QtCore.QRect(30, 350, 141, 20))
        self.repasswordsign.setObjectName(_fromUtf8("repasswordsign"))
        self.resiglineedit = QtGui.QLineEdit(signpage)
        self.resiglineedit.setGeometry(QtCore.QRect(200, 350, 201, 20))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.resiglineedit.setFont(font)
        self.resiglineedit.setEchoMode(QtGui.QLineEdit.Password)
        self.resiglineedit.setObjectName(_fromUtf8("resiglineedit"))

        self.retranslateUi(signpage)
        QtCore.QMetaObject.connectSlotsByName(signpage)

    def retranslateUi(self, signpage):
        signpage.setWindowTitle(_translate("signpage", "SignUP", None))
        self.name.setText(_translate("signpage", "Name", None))
        self.fname.setText(_translate("signpage", "First Nme", None))
        self.lname.setText(_translate("signpage", "Last Name", None))
        self.mobileno.setText(_translate("signpage", "Mobile NO", None))
        self.emailid.setText(_translate("signpage", "Email ID", None))
        self.userid.setText(_translate("signpage", "User ID", None))
        self.password2.setText(_translate("signpage", "Password", None))
        self.signin2.setText(_translate("signpage", "Sign In", None))
        self.repasswordsign.setText(_translate("signpage", "Re-Enter Password", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    signpage = QtGui.QWizardPage()
    ui = Ui_signpage()
    ui.setupUi(signpage)
    signpage.show()
    sys.exit(app.exec_())

