import sqlite3
conn = sqlite3.connect('place.db')
c=conn.cursor()
def create_table():

    c.execute("CREATE TABLE IF NOT EXISTS admin(Name TEXT,Address TEXT,Area TEXT,Tags TEXT,Descripation TEXT)")

    conn.commit()
    c.close()
    conn.close()
##def read():
##    c.execute("SELECT * FROM USERINFO")
##    for row in c.fetchall():
##        print(row)






##read()
create_table()    
