# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'viewplaceadmin.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_viewplaceforadmin(object):
    def setupUi(self, viewplaceforadmin):
        viewplaceforadmin.setObjectName(_fromUtf8("viewplaceforadmin"))
        viewplaceforadmin.resize(564, 412)
        self.viewplacenameforadmin = QtGui.QLabel(viewplaceforadmin)
        self.viewplacenameforadmin.setGeometry(QtCore.QRect(70, 50, 71, 31))
        self.viewplacenameforadmin.setObjectName(_fromUtf8("viewplacenameforadmin"))
        self.viewplaceaddressforadmin = QtGui.QLabel(viewplaceforadmin)
        self.viewplaceaddressforadmin.setGeometry(QtCore.QRect(70, 100, 71, 31))
        self.viewplaceaddressforadmin.setObjectName(_fromUtf8("viewplaceaddressforadmin"))
        self.viewplacedescriptionforadmin = QtGui.QLabel(viewplaceforadmin)
        self.viewplacedescriptionforadmin.setGeometry(QtCore.QRect(70, 210, 71, 31))
        self.viewplacedescriptionforadmin.setObjectName(_fromUtf8("viewplacedescriptionforadmin"))
        self.viewplacetagforadmin = QtGui.QLabel(viewplaceforadmin)
        self.viewplacetagforadmin.setGeometry(QtCore.QRect(70, 160, 71, 31))
        self.viewplacetagforadmin.setObjectName(_fromUtf8("viewplacetagforadmin"))
        self.viewplaceforadminlineEdit = QtGui.QLineEdit(viewplaceforadmin)
        self.viewplaceforadminlineEdit.setGeometry(QtCore.QRect(190, 60, 191, 20))
        self.viewplaceforadminlineEdit.setReadOnly(True)
        self.viewplaceforadminlineEdit.setObjectName(_fromUtf8("viewplaceforadminlineEdit"))
        self.viewplacetagsforadminlineEdit = QtGui.QLineEdit(viewplaceforadmin)
        self.viewplacetagsforadminlineEdit.setGeometry(QtCore.QRect(190, 170, 191, 20))
        self.viewplacetagsforadminlineEdit.setReadOnly(True)
        self.viewplacetagsforadminlineEdit.setObjectName(_fromUtf8("viewplacetagsforadminlineEdit"))
        self.viewplaceaddressforadminlineEdit = QtGui.QLineEdit(viewplaceforadmin)
        self.viewplaceaddressforadminlineEdit.setGeometry(QtCore.QRect(190, 110, 191, 51))
        self.viewplaceaddressforadminlineEdit.setReadOnly(True)
        self.viewplaceaddressforadminlineEdit.setObjectName(_fromUtf8("viewplaceaddressforadminlineEdit"))
        self.viewplacedescriptionforadminlineEdit = QtGui.QLineEdit(viewplaceforadmin)
        self.viewplacedescriptionforadminlineEdit.setGeometry(QtCore.QRect(190, 220, 201, 51))
        self.viewplacedescriptionforadminlineEdit.setReadOnly(True)
        self.viewplacedescriptionforadminlineEdit.setObjectName(_fromUtf8("viewplacedescriptionforadminlineEdit"))
###############
        db=sqlite3.connect('place.db')
        cursor=db.cursor()
        row= cursor.execute('''SELECT Name FROM admin''').fetchall()
        a=row[0][0]
        self.viewplaceforadminlineEdit.setText(a)
        
        row= cursor.execute('''SELECT Address FROM admin''').fetchall()
        b=row[0][0]
        self.viewplaceaddressforadminlineEdit.setText(b)
        
        row= cursor.execute('''SELECT Tags FROM admin''').fetchall()
        c=row[0][0]
        self.viewplacetagsforadminlineEdit.setText(c)
        
        row= cursor.execute('''SELECT Descripation FROM admin''').fetchall()
        d=row[0][0]
        self.viewplacedescriptionforadminlineEdit.setText(d)

         
        ##############
        self.retranslateUi(viewplaceforadmin)
        QtCore.QMetaObject.connectSlotsByName(viewplaceforadmin)

    def retranslateUi(self, viewplaceforadmin):
        viewplaceforadmin.setWindowTitle(_translate("viewplaceforadmin", "View Place", None))
        self.viewplacenameforadmin.setText(_translate("viewplaceforadmin", "Name:", None))
        self.viewplaceaddressforadmin.setText(_translate("viewplaceforadmin", "Address:", None))
        self.viewplacedescriptionforadmin.setText(_translate("viewplaceforadmin", "Description:", None))
        self.viewplacetagforadmin.setText(_translate("viewplaceforadmin", "Tags:", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    viewplaceforadmin = QtGui.QWidget()
    ui = Ui_viewplaceforadmin()
    ui.setupUi(viewplaceforadmin)
    viewplaceforadmin.show()
    sys.exit(app.exec_())

