# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'final.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from dars import Ui_descri
import sqlite3
import webbrowser

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_finals(object):
    def data(self):
        db=sqlite3.connect('answer.db')
        cursor=db.cursor()
        global  p
        p= cursor.execute('''SELECT First FROM question''').fetchall()
        print(p)
        global q
        q= cursor.execute('''SELECT Second FROM question''').fetchall()
        print(q)
        global r
        r= cursor.execute('''SELECT Third FROM question''').fetchall()
        print(r)
        global  s
        s= cursor.execute('''SELECT Four FROM question''').fetchall()
        print(s)
        global t
        t= cursor.execute('''SELECT Five FROM question''').fetchall()
        print(t)
        global u
        u= cursor.execute('''SELECT Six FROM question''').fetchall()
        print(u)
        global v
        v= cursor.execute('''SELECT Seven FROM question''').fetchall()
        print(v)
        global w
        w= cursor.execute('''SELECT Eight FROM question''').fetchall()
        print(w)
        global x
        x= cursor.execute('''SELECT Nine FROM question''').fetchall()
        print(x)
        global y
        y= cursor.execute('''SELECT Ten FROM question''').fetchall()
        print(y)
        if(p[0]==('1',)):    
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global p1
            p1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='beach' ''').fetchall()
            print(p1)
            cursor.close()
            db.close()
        if(q[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global q1
            q1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='hill station' ''').fetchall()
            print(q1)
            cursor.close()
            db.close()
         
        if(r[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global r1
            r1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='landscape' ''').fetchall()
            print(r1)
            cursor.close()
            db.close()
         
        if(s[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global s1
            s1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='museum' ''').fetchall()
            print(s1)
            cursor.close()
            db.close()
         
        if(t[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global t1
            t1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='temple' ''').fetchall()
            print(t1)
            cursor.close()
            db.close()
         
        if(u[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global u1
            u1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='fort' ''').fetchall()
            print(u1)
            cursor.close()
            db.close()
         
        if(v[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global v1
            v1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='adventureplace' ''').fetchall()
            print(v1)
            cursor.close()
            db.close()
         
        if(w[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global w1
            w1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='waterpark' ''').fetchall()
            print(w1)
            cursor.close()
            db.close()
         
        if(x[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global x1
            x1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='waterfall' ''').fetchall()
            print(x1)
            cursor.close()
         
        if(y[0]==('1',)):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            global y1
            y1= cursor.execute(''' SELECT Name FROM admin WHERE Tags='amuseum' ''').fetchall()
            print(y1)
            cursor.close()
            db.close()

        if(p[0]==('1',) and p1[0]==('goa',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(p1[0]))
            connection.commit()

        if(q[0]==('1',) and q1[0]==('kufri',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(q1[0]))
            connection.commit()
            
        if(r[0]==('1',) and r1[0]==('yumthang valley',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(r1[0]))
            connection.commit()
        if(s[0]==('1',) and s1[0]==('indian museum',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(s1[0]))
            connection.commit()
        if(t[0]==('1',) and t1[0]==('meenakshi',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(t1[0]))
            connection.commit()
        if(u[0]==('1',) and u1[0]==('gobindgarh',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(u1[0]))
            connection.commit()
        if(v[0]==('1',) and v1[0]==('bir billing',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(v1[0]))
            connection.commit()
        if(w[0]==('1',) and w1[0]==('esselworld',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(w1[0]))
            connection.commit()
        if(x[0]==('1',) and x1[0]==('dudhsagar',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(x1[0]))
            connection.commit()
        if(y[0]==('1',) and y1[0]==('indiannavalaviaionmuseum',)):
            connection  = sqlite3.connect("dummy.db")
            connection.execute("INSERT INTO help VALUES(?)",(y1[0]))
            connection.commit()

        ##
       ##  

      
        
    def setupUi(self, finals):
        finals.setObjectName(_fromUtf8("finals"))
        finals.resize(527, 315)
        self.finalcomboBox = QtGui.QComboBox(finals)
        self.finalcomboBox.setGeometry(QtCore.QRect(190, 60, 121, 22))
        self.finalcomboBox.setObjectName(_fromUtf8("finalcomboBox"))
        #####
               #cursor.execute(' DELETE FROM help')
        #db.commit()
        #db.close()
        ###
        self.lastlabel = QtGui.QLabel(finals)
        self.lastlabel.setGeometry(QtCore.QRect(200, 20, 101, 20))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(16)
        font.setBold(True)
        font.setWeight(75)
        self.lastlabel.setFont(font)
        self.lastlabel.setObjectName(_fromUtf8("lastlabel"))
        self.lastpushButton = QtGui.QPushButton(finals)
        self.lastpushButton.setGeometry(QtCore.QRect(80, 140, 121, 31))
        self.lastpushButton.setObjectName(_fromUtf8("lastpushButton"))
        ##
        self.lastpushButton.clicked.connect(self.insertdata111)
        self.lastpushButton.clicked.connect(self.info9)
        ##
        self.lastpushButton_2 = QtGui.QPushButton(finals)
        self.lastpushButton_2.setGeometry(QtCore.QRect(300, 140, 121, 31))
        self.lastpushButton_2.setObjectName(_fromUtf8("lastpushButton_2"))
        ##
        self.lastpushButton_2.clicked.connect(self.data)
        self.lastpushButton_2.clicked.connect(self.data1)
        ##
        ##
        self.lastpushButton_3 = QtGui.QPushButton(finals)
        self.lastpushButton_3.setGeometry(QtCore.QRect(200, 200, 121, 31))
        self.lastpushButton_3.setObjectName(_fromUtf8("lastpushButton_3"))
        self.lastpushButton_3.clicked.connect(self.data2)
        ###
        self.retranslateUi(finals)
        QtCore.QMetaObject.connectSlotsByName(finals)
    def data1(self):
        db=sqlite3.connect('dummy.db')
        cursor=db.cursor()
        row= cursor.execute('''SELECT Name FROM help''').fetchall()
        a11=row[0][0]
        print(a11)
        self.finalcomboBox.addItem("")
        self.finalcomboBox.addItem(a11)
        b11=row[1][0]
        print(b11)
        self.finalcomboBox.addItem(b11)
        c11=row[2][0]
        self.finalcomboBox.addItem(c11)
        d11=row[3][0]
        self.finalcomboBox.addItem(d11)
        e11=row[4][0]
        self.finalcomboBox.addItem(e11)
        ###
        
        ###


    def insertdata111(self):
        text=str(self.finalcomboBox.currentText())
        a=text
        print(a)
        connection  = sqlite3.connect("dummyy.db")
        connection.execute("INSERT INTO helpp VALUES(?)",(a,))
        connection.commit()
        connection.close()
        
    def data2(self):
        text=str(self.finalcomboBox.currentText())
        a=text
        webbrowser.open("https://www.google.co.in/maps/place/" + a)

    def info9(self):
        self.descri = QtGui.QWidget()
        self.ui = Ui_descri()
        self.ui.setupUi(self.descri)
        self.descri.show()

    def retranslateUi(self, finals):
        finals.setWindowTitle(_translate("finals", "Place", None))
        self.lastlabel.setText(_translate("finals", "Place Info", None))
        self.lastpushButton.setText(_translate("finals", "Description", None))
        self.lastpushButton_2.setText(_translate("finals", "refresh", None))
        ##
        self.lastpushButton_3.setText(_translate("finals", "MAP", None))
        ##


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    finals = QtGui.QWidget()
    ui = Ui_finals()
    ui.setupUi(finals)
    finals.show()
    sys.exit(app.exec_())

