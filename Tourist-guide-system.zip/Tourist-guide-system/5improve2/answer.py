import sqlite3
conn = sqlite3.connect('answer.db')
c=conn.cursor()
def create_table():

    c.execute("CREATE TABLE IF NOT EXISTS question(First TEXT,Second TEXT,Third TEXT,Four TEXT,Five TEXT,Six Text,Seven TEXT,Eight TEXT,Nine TEXT,Ten TEXT)")

    conn.commit()
    c.close()
    conn.close()
##def read():
##    c.execute("SELECT * FROM USERINFO")
##    for row in c.fetchall():
##        print(row)






##read()
create_table()    
