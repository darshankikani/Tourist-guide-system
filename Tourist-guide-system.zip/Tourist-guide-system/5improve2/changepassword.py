# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'changepassword.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3
#import sqlite3
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_changepassword(object):
     ###############################
    def showMessageBox33(self,title,message):
        msgBox = QtGui.QMessageBox()
        msgBox.setIcon(QtGui.QMessageBox.Warning)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtGui.QMessageBox.Ok)
        msgBox.exec_()
############################
    def changepasswordcheck(self):
        global teacherid
        d1=self.pldpsw_lineEdit.text()
        w1=self.newpsw_lineEdit.text()
        w2=self.reenter_lineEdit.text()

        db= sqlite3.connect("sign.db")
        cursor=db.cursor()
        cursor.execute("SELECT Password FROM trial WHERE Password = ?",(d1,))
        aaa=cursor.fetchone()

        result = cursor.execute("SELECT Password FROM trial WHERE Password = ?",(d1,))

        if(len(result.fetchall()) > 0):
            print("Password  match! ")
            if(w1==w2):
                self.money1()
            else:
                self.showMessageBox33('Warning','Password is not  match')
        else:
            self.showMessageBox33('Warning','Invalid Old Password')
            

        cursor.close()


      ###########################  

    def money1(self):
        db=sqlite3.connect('sign.db')
        old=self.pldpsw_lineEdit.text()
        a2=self.newpsw_lineEdit.text()
        cursor=db.cursor()
        cursor.execute('''SELECT Password FROM trial WHERE Password=?''',(old,))
        allrows4=cursor.fetchall()
 
        connection=sqlite3.connect("sign.db")
        connection.execute("UPDATE trial SET Password=? WHERE Password=?",(a2,old,))
        connection.commit()
        connection.close()
        self.pldpsw_lineEdit.clear()
        self.newpsw_lineEdit.clear()
        self.reenter_lineEdit.clear()

    def setupUi(self, changepassword):
        changepassword.setObjectName(_fromUtf8("changepassword"))
        changepassword.resize(537, 362)
        self.oldpassword = QtGui.QLabel(changepassword)
        self.oldpassword.setGeometry(QtCore.QRect(80, 70, 121, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.oldpassword.setFont(font)
        self.oldpassword.setObjectName(_fromUtf8("oldpassword"))
        self.newpassword = QtGui.QLabel(changepassword)
        self.newpassword.setGeometry(QtCore.QRect(70, 100, 121, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.newpassword.setFont(font)
        self.newpassword.setObjectName(_fromUtf8("newpassword"))
        self.reenterpassword = QtGui.QLabel(changepassword)
        self.reenterpassword.setGeometry(QtCore.QRect(30, 130, 161, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.reenterpassword.setFont(font)
        self.reenterpassword.setObjectName(_fromUtf8("reenterpassword"))
        self.pldpsw_lineEdit = QtGui.QLineEdit(changepassword)
        self.pldpsw_lineEdit.setGeometry(QtCore.QRect(220, 70, 201, 20))
        self.pldpsw_lineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.pldpsw_lineEdit.setObjectName(_fromUtf8("pldpsw_lineEdit"))
        self.newpsw_lineEdit = QtGui.QLineEdit(changepassword)
        self.newpsw_lineEdit.setGeometry(QtCore.QRect(220, 100, 201, 20))
        self.newpsw_lineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.newpsw_lineEdit.setObjectName(_fromUtf8("newpsw_lineEdit"))
        self.reenter_lineEdit = QtGui.QLineEdit(changepassword)
        self.reenter_lineEdit.setGeometry(QtCore.QRect(220, 130, 201, 20))
        self.reenter_lineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.reenter_lineEdit.setObjectName(_fromUtf8("reenter_lineEdit"))
        self.changepwdubmit = QtGui.QPushButton(changepassword)
        self.changepwdubmit.setGeometry(QtCore.QRect(200, 190, 111, 23))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.changepwdubmit.setFont(font)
        self.changepwdubmit.setObjectName(_fromUtf8("changepwdubmit"))
        #####
        self.changepwdubmit.clicked.connect(self.changepasswordcheck)
        #####
##############################################################
       # def money(self):
       # db=sqlite3.connect('sign.db')
       # cursor=db.cursor()
       # cursor.execute('''SELECT Password FROM trial ''')
       # allrows4=cursor.fetchall()
        #for row in allrows4:
           #print(row[0])
        #a=row[0]

        #connection=sqlite3.connect("sign.db")
        #connection.execute("UPDATE Password SET UniqueID=? WHERE User_Name=?",(a,usrname,))
        #connection.commit()
        #connection.close()
        ################################################################
        self.retranslateUi(changepassword)
        QtCore.QMetaObject.connectSlotsByName(changepassword)

    def retranslateUi(self, changepassword):
        changepassword.setWindowTitle(_translate("changepassword", "Change Password", None))
        self.oldpassword.setText(_translate("changepassword", "Old Password", None))
        self.newpassword.setText(_translate("changepassword", "New Password", None))
        self.reenterpassword.setText(_translate("changepassword", "Re-enter Password", None))
        self.changepwdubmit.setText(_translate("changepassword", "Submit", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    changepassword = QtGui.QWizardPage()
    ui = Ui_changepassword()
    ui.setupUi(changepassword)
    changepassword.show()
    sys.exit(app.exec_())

