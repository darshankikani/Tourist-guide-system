# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'userinfoadmin.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_userinfo(object):
    def setupUi(self, userinfo):
        userinfo.setObjectName(_fromUtf8("userinfo"))
        userinfo.resize(696, 405)
        self.usernameuserinfo = QtGui.QLabel(userinfo)
        self.usernameuserinfo.setGeometry(QtCore.QRect(80, 50, 81, 21))
        self.usernameuserinfo.setObjectName(_fromUtf8("usernameuserinfo"))
        self.usermnouserinfo = QtGui.QLabel(userinfo)
        self.usermnouserinfo.setGeometry(QtCore.QRect(80, 100, 81, 21))
        self.usermnouserinfo.setObjectName(_fromUtf8("usermnouserinfo"))
        self.useremailiduserinfo = QtGui.QLabel(userinfo)
        self.useremailiduserinfo.setGeometry(QtCore.QRect(80, 160, 81, 21))
        self.useremailiduserinfo.setObjectName(_fromUtf8("useremailiduserinfo"))
        self.userpassworduserinfo = QtGui.QLabel(userinfo)
        self.userpassworduserinfo.setGeometry(QtCore.QRect(80, 260, 81, 21))
        self.userpassworduserinfo.setObjectName(_fromUtf8("userpassworduserinfo"))
        self.useriduserinfo = QtGui.QLabel(userinfo)
        self.useriduserinfo.setGeometry(QtCore.QRect(80, 210, 81, 21))
        self.useriduserinfo.setObjectName(_fromUtf8("useriduserinfo"))
        self.usernameuserinfolineEdit = QtGui.QLineEdit(userinfo)
        self.usernameuserinfolineEdit.setGeometry(QtCore.QRect(170, 50, 251, 20))
        self.usernameuserinfolineEdit.setReadOnly(True)
        self.usernameuserinfolineEdit.setObjectName(_fromUtf8("usernameuserinfolineEdit"))
        self.usermobilenouserinfolineEdit = QtGui.QLineEdit(userinfo)
        self.usermobilenouserinfolineEdit.setGeometry(QtCore.QRect(170, 100, 251, 20))
        self.usermobilenouserinfolineEdit.setReadOnly(True)
        self.usermobilenouserinfolineEdit.setObjectName(_fromUtf8("usermobilenouserinfolineEdit"))
        self.useremailiduserinfolineEdit = QtGui.QLineEdit(userinfo)
        self.useremailiduserinfolineEdit.setGeometry(QtCore.QRect(170, 160, 251, 20))
        self.useremailiduserinfolineEdit.setReadOnly(True)
        self.useremailiduserinfolineEdit.setObjectName(_fromUtf8("useremailiduserinfolineEdit"))
        self.useridyserinfolineEdit = QtGui.QLineEdit(userinfo)
        self.useridyserinfolineEdit.setGeometry(QtCore.QRect(170, 210, 251, 20))
        self.useridyserinfolineEdit.setReadOnly(True)
        self.useridyserinfolineEdit.setObjectName(_fromUtf8("useridyserinfolineEdit"))
        self.userpassworduserinfolineEdit = QtGui.QLineEdit(userinfo)
        self.userpassworduserinfolineEdit.setGeometry(QtCore.QRect(170, 260, 251, 20))
        self.userpassworduserinfolineEdit.setReadOnly(True)
        self.userpassworduserinfolineEdit.setObjectName(_fromUtf8("userpassworduserinfolineEdit"))
#################
        db=sqlite3.connect('sign.db')
        cursor=db.cursor()
        row= cursor.execute('''SELECT Firstname FROM trial''').fetchall()
        a=row[0][0]
        self.usernameuserinfolineEdit.setText(a)
        
        row= cursor.execute('''SELECT Mobileno FROM trial''').fetchall()
        b=row[0][0]
        self.usermobilenouserinfolineEdit.setText(b)
        
        row= cursor.execute('''SELECT Emailid FROM trial''').fetchall()
        c=row[0][0]
        self.useremailiduserinfolineEdit.setText(c)
        
        row= cursor.execute('''SELECT Userid FROM trial''').fetchall()
        d=row[0][0]
        self.useridyserinfolineEdit.setText(d)

        row= cursor.execute('''SELECT Password FROM trial''').fetchall()
        e=row[0][0]
        self.userpassworduserinfolineEdit.setText(e)
        #######################
        self.retranslateUi(userinfo)
        QtCore.QMetaObject.connectSlotsByName(userinfo)

    def retranslateUi(self, userinfo):
        userinfo.setWindowTitle(_translate("userinfo", "User Information", None))
        self.usernameuserinfo.setText(_translate("userinfo", "Name", None))
        self.usermnouserinfo.setText(_translate("userinfo", "Mobile No", None))
        self.useremailiduserinfo.setText(_translate("userinfo", "Email Id", None))
        self.userpassworduserinfo.setText(_translate("userinfo", "Password", None))
        self.useriduserinfo.setText(_translate("userinfo", "User Id", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    userinfo = QtGui.QWidget()
    ui = Ui_userinfo()
    ui.setupUi(userinfo)
    userinfo.show()
    sys.exit(app.exec_())

