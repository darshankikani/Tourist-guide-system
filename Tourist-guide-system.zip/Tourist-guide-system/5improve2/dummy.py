import sqlite3
conn = sqlite3.connect('dummy.db')
c=conn.cursor()
def create_table():

    c.execute("CREATE TABLE IF NOT EXISTS help(Name TEXT)")

    conn.commit()
    c.close()
    conn.close()
##def read():
##    c.execute("SELECT * FROM USERINFO")
##    for row in c.fetchall():
##        print(row)






##read()
create_table()    
