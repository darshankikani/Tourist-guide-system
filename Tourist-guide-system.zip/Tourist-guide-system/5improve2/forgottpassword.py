# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'forgottpassword.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_forgottpassword(object):
    ###############################
    def showMessageBox22(self,title,message):
        msgBox = QtGui.QMessageBox()
        msgBox.setIcon(QtGui.QMessageBox.Warning)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtGui.QMessageBox.Ok)
        msgBox.exec_()
############################
    def forgotpasswordcheck(self):
        global teacherid
        c1=self.forgottmo_lineedit.text()
        f1=self.forgottnew_lineEdit.text()
        f2=self.forgottre_lineEdit.text()

        db= sqlite3.connect("sign.db")
        cursor=db.cursor()
        cursor.execute("SELECT Mobileno FROM trial WHERE Mobileno = ?",(c1,))
        aaa=cursor.fetchone()

        result = cursor.execute("SELECT Mobileno FROM trial WHERE Mobileno = ?",(c1,))

        if(len(result.fetchall()) > 0):
            print("Mobile  match! ")
            if(f1==f2):
                 self.money()
            else:
                self.showMessageBox22('Warning','Password is not match')
        else:
            self.showMessageBox22('Warning','Invalid Mobile No')
            

        cursor.close()


      ###########################  

    ##########################
    def money(self):
        db=sqlite3.connect('sign.db')
        mobileno=self.forgottmo_lineedit.text()
        a1=self.forgottnew_lineEdit.text()
        cursor=db.cursor()
        cursor.execute('''SELECT Mobileno FROM trial WHERE Mobileno=?''',(mobileno,))
        allrows4=cursor.fetchall()
        for row in allrows4:
            print(row[0])
        a=row[0]

        connection=sqlite3.connect("sign.db")
        connection.execute("UPDATE trial SET Password=? WHERE Mobileno=?",(a1,mobileno,))
        connection.commit()
        connection.close()
        self.forgottmo_lineedit.clear()
        self.forgottnew_lineEdit.clear()
        self.forgottre_lineEdit.clear()

        
    def setupUi(self, forgottpassword):
        forgottpassword.setObjectName(_fromUtf8("forgottpassword"))
        forgottpassword.resize(667, 324)
        self.forgottmobile = QtGui.QLabel(forgottpassword)
        self.forgottmobile.setGeometry(QtCore.QRect(80, 60, 81, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.forgottmobile.setFont(font)
        self.forgottmobile.setObjectName(_fromUtf8("forgottmobile"))
        self.forgottnewpsw = QtGui.QLabel(forgottpassword)
        self.forgottnewpsw.setGeometry(QtCore.QRect(50, 90, 111, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.forgottnewpsw.setFont(font)
        self.forgottnewpsw.setObjectName(_fromUtf8("forgottnewpsw"))
        self.forgottrepsw = QtGui.QLabel(forgottpassword)
        self.forgottrepsw.setGeometry(QtCore.QRect(20, 120, 141, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.forgottrepsw.setFont(font)
        self.forgottrepsw.setObjectName(_fromUtf8("forgottrepsw"))
        self.forgottmo_lineedit = QtGui.QLineEdit(forgottpassword)
        self.forgottmo_lineedit.setGeometry(QtCore.QRect(170, 60, 201, 20))
        self.forgottmo_lineedit.setObjectName(_fromUtf8("forgottmo_lineedit"))
        self.forgottnew_lineEdit = QtGui.QLineEdit(forgottpassword)
        self.forgottnew_lineEdit.setGeometry(QtCore.QRect(170, 90, 231, 20))
        self.forgottnew_lineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.forgottnew_lineEdit.setObjectName(_fromUtf8("forgottnew_lineEdit"))
        self.forgottre_lineEdit = QtGui.QLineEdit(forgottpassword)
        self.forgottre_lineEdit.setGeometry(QtCore.QRect(170, 120, 231, 20))
        self.forgottre_lineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.forgottre_lineEdit.setObjectName(_fromUtf8("forgottre_lineEdit"))
        self.forgottpswsubmit = QtGui.QPushButton(forgottpassword)
        self.forgottpswsubmit.setGeometry(QtCore.QRect(220, 180, 75, 23))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.forgottpswsubmit.setFont(font)
        self.forgottpswsubmit.setObjectName(_fromUtf8("forgottpswsubmit"))
################
        self.forgottpswsubmit.clicked.connect(self.forgotpasswordcheck)
        ###################
        self.retranslateUi(forgottpassword)
        QtCore.QMetaObject.connectSlotsByName(forgottpassword)

    def retranslateUi(self, forgottpassword):
        forgottpassword.setWindowTitle(_translate("forgottpassword", "ForgotPassword", None))
        self.forgottmobile.setText(_translate("forgottpassword", "Mobile No", None))
        self.forgottnewpsw.setText(_translate("forgottpassword", "New Password", None))
        self.forgottrepsw.setText(_translate("forgottpassword", "Re-Enter password", None))
        self.forgottpswsubmit.setText(_translate("forgottpassword", "Submit", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    forgottpassword = QtGui.QWizardPage()
    ui = Ui_forgottpassword()
    ui.setupUi(forgottpassword)
    forgottpassword.show()
    sys.exit(app.exec_())

