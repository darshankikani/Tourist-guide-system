# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'question.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from final import Ui_finals
import sqlite3
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_userquestion(object):
    #####
    def first(self):
        if(self.y1radioButton.isChecked()):
            a=1
        else:
            a=0
        print(a)
        if(self.y2radioButton.isChecked()):
            b=1
        else:
            b=0
        print(b)

        if(self.y3radioButton.isChecked()):
            c=1
        else:
            c=0
        print(c)

        if(self.y4radioButton.isChecked()):
            d=1
        else:
            d=0
        print(d)

        if(self.y5radioButton.isChecked()):
            e=1
        else:
            e=0
        print(e)

        if(self.y6radioButton.isChecked()):
            f=1
        else:
            f=0
        print(f)

        if(self.y7radioButton.isChecked()):
            g=1
        else:
            g=0
        print(g)

        if(self.y8radioButton.isChecked()):
            h=1
        else:
            h=0
        print(h)

        if(self.y9radioButton.isChecked()):
            i=1
        else:
            i=0
        print(i)
        if(self.y10radioButton.isChecked()):
            j=1
        else:
            j=0
        print(j)

        connection  = sqlite3.connect("answer.db")
        connection.execute("INSERT INTO question VALUES(?,?,?,?,?,?,?,?,?,?)",(a,b,c,d,e,f,g,h,i,j))
        connection.commit()
        connection.close()

        self.info8()
        
        ####
    def setupUi(self, userquestion):
        userquestion.setObjectName(_fromUtf8("userquestion"))
        userquestion.resize(618, 585)
        self.mainlabelforuser = QtGui.QLabel(userquestion)
        self.mainlabelforuser.setGeometry(QtCore.QRect(200, 20, 181, 20))
        self.mainlabelforuser.setObjectName(_fromUtf8("mainlabelforuser"))
        self.q1 = QtGui.QLabel(userquestion)
        self.q1.setGeometry(QtCore.QRect(40, 70, 221, 31))
        self.q1.setObjectName(_fromUtf8("q1"))
        self.q2 = QtGui.QLabel(userquestion)
        self.q2.setGeometry(QtCore.QRect(40, 120, 251, 31))
        self.q2.setObjectName(_fromUtf8("q2"))
        self.q3 = QtGui.QLabel(userquestion)
        self.q3.setGeometry(QtCore.QRect(40, 170, 291, 31))
        self.q3.setObjectName(_fromUtf8("q3"))
        self.q4 = QtGui.QLabel(userquestion)
        self.q4.setGeometry(QtCore.QRect(40, 220, 231, 31))
        self.q4.setObjectName(_fromUtf8("q4"))
        self.q6 = QtGui.QLabel(userquestion)
        self.q6.setGeometry(QtCore.QRect(40, 320, 201, 31))
        self.q6.setObjectName(_fromUtf8("q6"))
        self.q5 = QtGui.QLabel(userquestion)
        self.q5.setGeometry(QtCore.QRect(40, 270, 231, 31))
        self.q5.setObjectName(_fromUtf8("q5"))
        self.q8 = QtGui.QLabel(userquestion)
        self.q8.setGeometry(QtCore.QRect(40, 420, 221, 31))
        self.q8.setObjectName(_fromUtf8("q8"))
        self.q7 = QtGui.QLabel(userquestion)
        self.q7.setGeometry(QtCore.QRect(40, 370, 311, 31))
        self.q7.setObjectName(_fromUtf8("q7"))
        self.q9 = QtGui.QLabel(userquestion)
        self.q9.setGeometry(QtCore.QRect(40, 470, 241, 31))
        self.q9.setObjectName(_fromUtf8("q9"))
        self.q10 = QtGui.QLabel(userquestion)
        self.q10.setGeometry(QtCore.QRect(40, 520, 301, 31))
        self.q10.setObjectName(_fromUtf8("q10"))
        self.submitforquestion = QtGui.QPushButton(userquestion)
        self.submitforquestion.setGeometry(QtCore.QRect(490, 550, 111, 31))
        self.submitforquestion.setObjectName(_fromUtf8("submitforquestion"))
        ##
        self.submitforquestion.clicked.connect(self.first)
        ##
        self.y1radioButton = QtGui.QRadioButton(userquestion)
        self.y1radioButton.setGeometry(QtCore.QRect(380, 70, 61, 17))
        self.y1radioButton.setCheckable(True)
        self.y1radioButton.setChecked(False)
        self.y1radioButton.setAutoRepeat(False)
        self.y1radioButton.setAutoExclusive(False)
        self.y1radioButton.setObjectName(_fromUtf8("y1radioButton"))
        ##
        ##
        self.y2radioButton = QtGui.QRadioButton(userquestion)
        self.y2radioButton.setGeometry(QtCore.QRect(380, 120, 61, 17))
        self.y2radioButton.setCheckable(True)
        self.y2radioButton.setChecked(False)
        self.y2radioButton.setAutoRepeat(False)
        self.y2radioButton.setAutoExclusive(False)
        self.y2radioButton.setObjectName(_fromUtf8("y2radioButton"))
        self.y3radioButton = QtGui.QRadioButton(userquestion)
        self.y3radioButton.setGeometry(QtCore.QRect(380, 180, 61, 17))
        self.y3radioButton.setCheckable(True)
        self.y3radioButton.setChecked(False)
        self.y3radioButton.setAutoRepeat(False)
        self.y3radioButton.setAutoExclusive(False)
        self.y3radioButton.setObjectName(_fromUtf8("y3radioButton"))
        self.y4radioButton = QtGui.QRadioButton(userquestion)
        self.y4radioButton.setGeometry(QtCore.QRect(380, 230, 61, 17))
        self.y4radioButton.setCheckable(True)
        self.y4radioButton.setChecked(False)
        self.y4radioButton.setAutoRepeat(False)
        self.y4radioButton.setAutoExclusive(False)
        self.y4radioButton.setObjectName(_fromUtf8("y4radioButton"))
        self.y5radioButton = QtGui.QRadioButton(userquestion)
        self.y5radioButton.setGeometry(QtCore.QRect(380, 280, 61, 17))
        self.y5radioButton.setCheckable(True)
        self.y5radioButton.setChecked(False)
        self.y5radioButton.setAutoRepeat(False)
        self.y5radioButton.setAutoExclusive(False)
        self.y5radioButton.setObjectName(_fromUtf8("y5radioButton"))
        self.y6radioButton = QtGui.QRadioButton(userquestion)
        self.y6radioButton.setGeometry(QtCore.QRect(380, 330, 61, 17))
        self.y6radioButton.setCheckable(True)
        self.y6radioButton.setChecked(False)
        self.y6radioButton.setAutoRepeat(False)
        self.y6radioButton.setAutoExclusive(False)
        self.y6radioButton.setObjectName(_fromUtf8("y6radioButton"))
        self.y7radioButton = QtGui.QRadioButton(userquestion)
        self.y7radioButton.setGeometry(QtCore.QRect(380, 380, 61, 17))
        self.y7radioButton.setCheckable(True)
        self.y7radioButton.setChecked(False)
        self.y7radioButton.setAutoRepeat(False)
        self.y7radioButton.setAutoExclusive(False)
        self.y7radioButton.setObjectName(_fromUtf8("y7radioButton"))
        self.y8radioButton = QtGui.QRadioButton(userquestion)
        self.y8radioButton.setGeometry(QtCore.QRect(380, 430, 61, 17))
        self.y8radioButton.setCheckable(True)
        self.y8radioButton.setChecked(False)
        self.y8radioButton.setAutoRepeat(False)
        self.y8radioButton.setAutoExclusive(False)
        self.y8radioButton.setObjectName(_fromUtf8("y8radioButton"))
        self.y9radioButton = QtGui.QRadioButton(userquestion)
        self.y9radioButton.setGeometry(QtCore.QRect(380, 480, 61, 17))
        self.y9radioButton.setCheckable(True)
        self.y9radioButton.setChecked(False)
        self.y9radioButton.setAutoRepeat(False)
        self.y9radioButton.setAutoExclusive(False)
        self.y9radioButton.setObjectName(_fromUtf8("y9radioButton"))
        self.y10radioButton = QtGui.QRadioButton(userquestion)
        self.y10radioButton.setGeometry(QtCore.QRect(380, 530, 61, 17))
        self.y10radioButton.setCheckable(True)
        self.y10radioButton.setAutoRepeat(False)
        self.y10radioButton.setAutoExclusive(False)
        self.y10radioButton.setObjectName(_fromUtf8("y10radioButton"))
        self.n1radioButton = QtGui.QRadioButton(userquestion)
        self.n1radioButton.setGeometry(QtCore.QRect(480, 70, 61, 17))
        self.n1radioButton.setAutoExclusive(False)
        self.n1radioButton.setObjectName(_fromUtf8("n1radioButton"))
        self.n2radioButton = QtGui.QRadioButton(userquestion)
        self.n2radioButton.setGeometry(QtCore.QRect(480, 120, 61, 17))
        self.n2radioButton.setAutoExclusive(False)
        self.n2radioButton.setObjectName(_fromUtf8("n2radioButton"))
        self.n3radioButton = QtGui.QRadioButton(userquestion)
        self.n3radioButton.setGeometry(QtCore.QRect(480, 180, 61, 17))
        self.n3radioButton.setAutoExclusive(False)
        self.n3radioButton.setObjectName(_fromUtf8("n3radioButton"))
        self.n4radioButton = QtGui.QRadioButton(userquestion)
        self.n4radioButton.setGeometry(QtCore.QRect(480, 230, 61, 17))
        self.n4radioButton.setAutoExclusive(False)
        self.n4radioButton.setObjectName(_fromUtf8("n4radioButton"))
        self.n5radioButton = QtGui.QRadioButton(userquestion)
        self.n5radioButton.setGeometry(QtCore.QRect(480, 280, 61, 17))
        self.n5radioButton.setAutoExclusive(False)
        self.n5radioButton.setObjectName(_fromUtf8("n5radioButton"))
        self.n6radioButton = QtGui.QRadioButton(userquestion)
        self.n6radioButton.setGeometry(QtCore.QRect(480, 330, 61, 17))
        self.n6radioButton.setAutoExclusive(False)
        self.n6radioButton.setObjectName(_fromUtf8("n6radioButton"))
        self.n7radioButton = QtGui.QRadioButton(userquestion)
        self.n7radioButton.setGeometry(QtCore.QRect(480, 380, 61, 17))
        self.n7radioButton.setAutoExclusive(False)
        self.n7radioButton.setObjectName(_fromUtf8("n7radioButton"))
        self.n8radioButton = QtGui.QRadioButton(userquestion)
        self.n8radioButton.setGeometry(QtCore.QRect(480, 430, 61, 17))
        self.n8radioButton.setAutoExclusive(False)
        self.n8radioButton.setObjectName(_fromUtf8("n8radioButton"))
        self.n9radioButton = QtGui.QRadioButton(userquestion)
        self.n9radioButton.setGeometry(QtCore.QRect(480, 480, 61, 17))
        self.n9radioButton.setAutoExclusive(False)
        self.n9radioButton.setObjectName(_fromUtf8("n9radioButton"))
        self.n10radioButton = QtGui.QRadioButton(userquestion)
        self.n10radioButton.setGeometry(QtCore.QRect(480, 530, 61, 17))
        self.n10radioButton.setAutoExclusive(False)
        self.n10radioButton.setObjectName(_fromUtf8("n10radioButton"))

        self.retranslateUi(userquestion)
        QtCore.QMetaObject.connectSlotsByName(userquestion)

    def retranslateUi(self, userquestion):
        userquestion.setWindowTitle(_translate("userquestion", "Trip Plan", None))
        self.mainlabelforuser.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; text-decoration: underline;\">Answer The Question</span></p></body></html>", None))
        self.q1.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to visit beach?</span></p></body></html>", None))
        self.q2.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to visit Hill Station?</span></p><p><br/></p></body></html>", None))
        self.q3.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to have landscape view?</span></p></body></html>", None))
        self.q4.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to visit museum?</span></p></body></html>", None))
        self.q6.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to visit Fort?</span></p></body></html>", None))
        self.q5.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to visit Tample?</span></p></body></html>", None))
        self.q8.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to Water Sport?</span></p></body></html>", None))
        self.q7.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to visit Adventurous Place?</span></p></body></html>", None))
        self.q9.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to visit Waterfalls?</span></p></body></html>", None))
        self.q10.setText(_translate("userquestion", "<html><head/><body><p><span style=\" font-size:12pt;\">Would you like to visit Aviation Museum?</span></p></body></html>", None))
        self.submitforquestion.setText(_translate("userquestion", "SUBMIT", None))
        self.y1radioButton.setText(_translate("userquestion", "YES", None))
        self.y2radioButton.setText(_translate("userquestion", "YES", None))
        self.y3radioButton.setText(_translate("userquestion", "YES", None))
        self.y4radioButton.setText(_translate("userquestion", "YES", None))
        self.y5radioButton.setText(_translate("userquestion", "YES", None))
        self.y6radioButton.setText(_translate("userquestion", "YES", None))
        self.y7radioButton.setText(_translate("userquestion", "YES", None))
        self.y8radioButton.setText(_translate("userquestion", "YES", None))
        self.y9radioButton.setText(_translate("userquestion", "YES", None))
        self.y10radioButton.setText(_translate("userquestion", "YES", None))
        self.n1radioButton.setText(_translate("userquestion", "No", None))
        self.n2radioButton.setText(_translate("userquestion", "No", None))
        self.n3radioButton.setText(_translate("userquestion", "No", None))
        self.n4radioButton.setText(_translate("userquestion", "No", None))
        self.n5radioButton.setText(_translate("userquestion", "No", None))
        self.n6radioButton.setText(_translate("userquestion", "No", None))
        self.n7radioButton.setText(_translate("userquestion", "No", None))
        self.n8radioButton.setText(_translate("userquestion", "No", None))
        self.n9radioButton.setText(_translate("userquestion", "No", None))
        self.n10radioButton.setText(_translate("userquestion", "No", None))

        ###
    def info8(self):
        self.finals = QtGui.QWidget()
        self.ui = Ui_finals()
        self.ui.setupUi(self.finals)
        self.finals.show()

        ###


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    userquestion = QtGui.QWidget()
    ui = Ui_userquestion()
    ui.setupUi(userquestion)
    userquestion.show()
    sys.exit(app.exec_())

