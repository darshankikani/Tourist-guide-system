# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'admin.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from viewplaceadmin import Ui_viewplaceforadmin
from userinfoadmin import Ui_userinfo
import sqlite3

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Form(object):
    #########
    def showMessageBox(self,title,message):
        msgBox = QtGui.QMessageBox()
        msgBox.setIcon(QtGui.QMessageBox.Warning)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtGui.QMessageBox.Ok)
        msgBox.exec_()

    #############
    ##############check###############
    def check(self):
        ##global name
        name = self.viewplacelineEdit.text()
            
        db= sqlite3.connect("place.db")
        cursor=db.cursor()
        cursor.execute("SELECT Name FROM admin WHERE Name = ?",(name,))
        aaa=cursor.fetchone()
        
            
        result = cursor.execute("SELECT Name FROM admin WHERE Name = ?",(name,))

        if(len(result.fetchall()) > 0):
                print("Place Found ! ")
                self.info5()
        else:
           
                print("Place Not Found !")
                self.showMessageBox('Warning','Invalid Place Name')

        cursor.close()

    ######################################
        ##########################check1###########
    def check1(self):
        ##global name
        uname =self.viewuserusernamelineEdit.text()
        mno=self.viewusermnolineEdit.text()
            
        db= sqlite3.connect("sign.db")
        cursor=db.cursor()
        cursor.execute("SELECT Firstname AND Mobileno FROM trial WHERE Firstname = ? AND Mobileno=?",(uname,mno,))
        aaa=cursor.fetchone()
        
            
        result = cursor.execute("SELECT Firstname AND Mobileno FROM trial WHERE Firstname = ? AND Mobileno=?",(uname,mno,))

        if(len(result.fetchall()) > 0):
                print("User Found ! ")
                self.info6()
        else:
           
                print("User  Not Found !")
                self.showMessageBox('Warning','Invalid Username or Mobile No')

        cursor.close()

        ############################
    #################################
    def insertData(self):
            name = self.nameforplacelineEdit.text()
            address= self.addressforplacelineEdit.text()
            area = self.areaforplacelineEdit.text()
            tags=self.tagsforplacelineEdit.text()
            description=self.descriptionforplacelineEdi.text()
            
            connection  = sqlite3.connect("place.db")
            connection.execute("INSERT INTO admin VALUES(?,?,?,?,?)",(name,address,area,tags,description))
            connection.commit()
            connection.close()
            self.nameforplacelineEdit.clear()
            self.addressforplacelineEdit.clear()
            self.areaforplacelineEdit.clear()
            self.tagsforplacelineEdit.clear()
            self.descriptionforplacelineEdi.clear()
            
    #################################
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(652, 391)
        self.admin = QtGui.QTabWidget(Form)
        self.admin.setGeometry(QtCore.QRect(0, 0, 651, 401))
        self.admin.setObjectName(_fromUtf8("admin"))
        self.addplace1 = QtGui.QWidget()
        self.addplace1.setObjectName(_fromUtf8("addplace1"))
        self.nameforplace = QtGui.QLabel(self.addplace1)
        self.nameforplace.setGeometry(QtCore.QRect(70, 40, 101, 21))
        self.nameforplace.setObjectName(_fromUtf8("nameforplace"))
        self.addressforplace = QtGui.QLabel(self.addplace1)
        self.addressforplace.setGeometry(QtCore.QRect(70, 90, 101, 21))
        self.addressforplace.setObjectName(_fromUtf8("addressforplace"))
        self.areaforplace = QtGui.QLabel(self.addplace1)
        self.areaforplace.setGeometry(QtCore.QRect(70, 150, 101, 21))
        self.areaforplace.setObjectName(_fromUtf8("areaforplace"))
        self.tagsforplace = QtGui.QLabel(self.addplace1)
        self.tagsforplace.setGeometry(QtCore.QRect(70, 200, 101, 21))
        self.tagsforplace.setObjectName(_fromUtf8("tagsforplace"))
        self.descriptionforplace = QtGui.QLabel(self.addplace1)
        self.descriptionforplace.setGeometry(QtCore.QRect(70, 240, 101, 21))
        self.descriptionforplace.setObjectName(_fromUtf8("descriptionforplace"))
        self.nameforplacelineEdit = QtGui.QLineEdit(self.addplace1)
        self.nameforplacelineEdit.setGeometry(QtCore.QRect(150, 40, 261, 20))
        self.nameforplacelineEdit.setObjectName(_fromUtf8("nameforplacelineEdit"))
        self.addressforplacelineEdit = QtGui.QLineEdit(self.addplace1)
        self.addressforplacelineEdit.setGeometry(QtCore.QRect(150, 90, 301, 41))
        self.addressforplacelineEdit.setObjectName(_fromUtf8("addressforplacelineEdit"))
        self.areaforplacelineEdit = QtGui.QLineEdit(self.addplace1)
        self.areaforplacelineEdit.setGeometry(QtCore.QRect(150, 150, 261, 20))
        self.areaforplacelineEdit.setObjectName(_fromUtf8("areaforplacelineEdit"))
        self.tagsforplacelineEdit = QtGui.QLineEdit(self.addplace1)
        self.tagsforplacelineEdit.setGeometry(QtCore.QRect(150, 200, 261, 20))
        self.tagsforplacelineEdit.setObjectName(_fromUtf8("tagsforplacelineEdit"))
        self.descriptionforplacelineEdi = QtGui.QLineEdit(self.addplace1)
        self.descriptionforplacelineEdi.setGeometry(QtCore.QRect(150, 240, 261, 20))
        self.descriptionforplacelineEdi.setObjectName(_fromUtf8("descriptionforplacelineEdi"))
        self.adminplacesubmit = QtGui.QPushButton(self.addplace1)
        self.adminplacesubmit.setGeometry(QtCore.QRect(220, 300, 111, 31))
        self.adminplacesubmit.setObjectName(_fromUtf8("adminplacesubmit"))
        ######################
        self.adminplacesubmit.clicked.connect(self.insertData)
        ###########################
        self.admin.addTab(self.addplace1, _fromUtf8(""))
        self.viewplace1 = QtGui.QWidget()
        self.viewplace1.setObjectName(_fromUtf8("viewplace1"))
        self.viewplacename = QtGui.QLabel(self.viewplace1)
        self.viewplacename.setGeometry(QtCore.QRect(80, 60, 71, 31))
        self.viewplacename.setObjectName(_fromUtf8("viewplacename"))
        self.viewplacelineEdit = QtGui.QLineEdit(self.viewplace1)
        self.viewplacelineEdit.setGeometry(QtCore.QRect(190, 70, 231, 20))
        self.viewplacelineEdit.setObjectName(_fromUtf8("viewplacelineEdit"))
        self.viewplacesubmit = QtGui.QPushButton(self.viewplace1)
        self.viewplacesubmit.setGeometry(QtCore.QRect(240, 160, 91, 31))
        self.viewplacesubmit.setObjectName(_fromUtf8("viewplacesubmit"))
        #########################
        self.viewplacesubmit.clicked.connect(self.check)
        ##########################
        self.admin.addTab(self.viewplace1, _fromUtf8(""))
        self.viewuser1 = QtGui.QWidget()
        self.viewuser1.setObjectName(_fromUtf8("viewuser1"))
        self.viewuserusernamelabel = QtGui.QLabel(self.viewuser1)
        self.viewuserusernamelabel.setGeometry(QtCore.QRect(90, 60, 71, 16))
        self.viewuserusernamelabel.setObjectName(_fromUtf8("viewuserusernamelabel"))
        self.viewusermnolabel = QtGui.QLabel(self.viewuser1)
        self.viewusermnolabel.setGeometry(QtCore.QRect(90, 110, 71, 16))
        self.viewusermnolabel.setObjectName(_fromUtf8("viewusermnolabel"))
        self.viewuserusernamelineEdit = QtGui.QLineEdit(self.viewuser1)
        self.viewuserusernamelineEdit.setGeometry(QtCore.QRect(180, 60, 211, 20))
        self.viewuserusernamelineEdit.setObjectName(_fromUtf8("viewuserusernamelineEdit"))
        self.viewusermnolineEdit = QtGui.QLineEdit(self.viewuser1)
        self.viewusermnolineEdit.setGeometry(QtCore.QRect(180, 110, 211, 20))
        self.viewusermnolineEdit.setObjectName(_fromUtf8("viewusermnolineEdit"))
        self.viewusersubmit = QtGui.QPushButton(self.viewuser1)
        self.viewusersubmit.setGeometry(QtCore.QRect(230, 180, 101, 31))
        self.viewusersubmit.setObjectName(_fromUtf8("viewusersubmit"))
        #################
        self.viewusersubmit.clicked.connect(self.check1)
        #################
        self.admin.addTab(self.viewuser1, _fromUtf8(""))

        self.retranslateUi(Form)
        self.admin.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_translate("Form", "Form", None))
        self.nameforplace.setText(_translate("Form", "NAME:", None))
        self.addressforplace.setText(_translate("Form", "ADDRESS:", None))
        self.areaforplace.setText(_translate("Form", "AREA:", None))
        self.tagsforplace.setText(_translate("Form", "TAGS:", None))
        self.descriptionforplace.setText(_translate("Form", "DESCRIPATION:", None))
        self.adminplacesubmit.setText(_translate("Form", "SUBMIT", None))
        self.admin.setTabText(self.admin.indexOf(self.addplace1), _translate("Form", "Add Place", None))
        self.viewplacename.setText(_translate("Form", "PLACE NAME", None))
        self.viewplacesubmit.setText(_translate("Form", "SUBMIT", None))
        self.admin.setTabText(self.admin.indexOf(self.viewplace1), _translate("Form", "View Place", None))
        self.viewuserusernamelabel.setText(_translate("Form", "User Name:", None))
        self.viewusermnolabel.setText(_translate("Form", "Mo.no:", None))
        self.viewusersubmit.setText(_translate("Form", "SUBMIT", None))
        self.admin.setTabText(self.admin.indexOf(self.viewuser1), _translate("Form", "View User", None))

    def info5(self):
        self.viewplaceforadmin = QtGui.QWidget()
        self.ui = Ui_viewplaceforadmin()
        self.ui.setupUi(self.viewplaceforadmin)
        self.viewplaceforadmin.show()
    
    def info6(self):
        self.userinfo = QtGui.QWidget()
        self.ui = Ui_userinfo()
        self.ui.setupUi(self.userinfo)
        self.userinfo.show()
if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    Form = QtGui.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())

