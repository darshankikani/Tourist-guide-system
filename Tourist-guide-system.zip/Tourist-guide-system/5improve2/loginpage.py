# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'loginpage.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from changepassword import Ui_changepassword
from forgottpassword import Ui_forgottpassword
from signpage import Ui_signpage
from admin import Ui_Form
from question import Ui_userquestion
import sqlite3
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_loginpage(object):
    ##################
    def showMessageBox(self,title,message):
        msgBox = QtGui.QMessageBox()
        msgBox.setIcon(QtGui.QMessageBox.Warning)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtGui.QMessageBox.Ok)
        msgBox.exec_()
    ###################

#################
    def loginCheck(self):
            global fname
            fname = self.id.text()
            password =self.passw.text()

            db= sqlite3.connect("sign.db")
            cursor=db.cursor()
            cursor.execute("SELECT Userid,Password FROM trial WHERE Userid = ? AND Password = ?",(fname,password))
            aaa=cursor.fetchone()
        
            
            result = cursor.execute("SELECT Userid,Password FROM trial WHERE Userid = ? AND Password = ?",(fname,password))
####admin login check #########            
            x="darshan1234"
            if(password==x):
                self.info4()
      #########################          
            else:
                if(len(result.fetchall()) > 0):
                    print("User Found ! ")
                    self.info7()
                else:
           
                    print("User Not Found !")
                    self.showMessageBox('Warning','Invalid Username And Password')

            cursor.close()
#################3    
    def setupUi(self, loginpage):
        loginpage.setObjectName(_fromUtf8("loginpage"))
        loginpage.resize(544, 327)
        self.loginid = QtGui.QLabel(loginpage)
        self.loginid.setGeometry(QtCore.QRect(80, 90, 71, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.loginid.setFont(font)
        self.loginid.setObjectName(_fromUtf8("loginid"))
        self.password = QtGui.QLabel(loginpage)
        self.password.setGeometry(QtCore.QRect(80, 140, 71, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.password.setFont(font)
        self.password.setObjectName(_fromUtf8("password"))
        self.id = QtGui.QLineEdit(loginpage)
        self.id.setGeometry(QtCore.QRect(170, 89, 171, 31))
        self.id.setObjectName(_fromUtf8("id"))
        self.passw = QtGui.QLineEdit(loginpage)
        self.passw.setGeometry(QtCore.QRect(170, 140, 171, 31))
        self.passw.setEchoMode(QtGui.QLineEdit.Password)
        self.passw.setObjectName(_fromUtf8("pass"))
        self.login = QtGui.QPushButton(loginpage)
        self.login.setGeometry(QtCore.QRect(200, 200, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.login.setFont(font)
        self.login.setObjectName(_fromUtf8("login"))
        ########
        self.login.clicked.connect(self.loginCheck)
        ######
        self.signin = QtGui.QPushButton(loginpage)
        self.signin.setGeometry(QtCore.QRect(50, 200, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.signin.setFont(font)
        self.signin.setObjectName(_fromUtf8("signin"))
        #########
        self.signin.clicked.connect(self.info1)
        ########
        self.change = QtGui.QPushButton(loginpage)
        self.change.setGeometry(QtCore.QRect(350, 200, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.change.setFont(font)
        self.change.setObjectName(_fromUtf8("change"))
        ######
        self.change.clicked.connect(self.info2)
        ######
        self.forgott = QtGui.QPushButton(loginpage)
        self.forgott.setGeometry(QtCore.QRect(420, 280, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.forgott.setFont(font)
        self.forgott.setObjectName(_fromUtf8("forgott"))
#######
        self.forgott.clicked.connect(self.info3)
        #####
        self.retranslateUi(loginpage)
        QtCore.QMetaObject.connectSlotsByName(loginpage)

    def retranslateUi(self, loginpage):
        loginpage.setWindowTitle(_translate("loginpage", "Loginpage", None))
        self.loginid.setText(_translate("loginpage", "Login Id", None))
        self.password.setText(_translate("loginpage", "Password", None))
        self.login.setText(_translate("loginpage", "Login", None))
        self.signin.setText(_translate("loginpage", "Sign In", None))
        self.change.setText(_translate("loginpage", "Change Password", None))
        self.forgott.setText(_translate("loginpage", "Forgott Password", None))


    def info(self):
        self.tsubmit = QtGui.QTabWidget()
        self.ui = Ui_tsubmit()
        self.ui.setupUi(self.tsubmit)
        self.tsubmit.show()

    def info1(self):
        self.signpage = QtGui.QWizardPage()
        self.ui = Ui_signpage()
        self.ui.setupUi(self.signpage)
        self.signpage.show()

    def info2(self):
        self.changepassword = QtGui.QWizardPage()
        self.ui = Ui_changepassword()
        self.ui.setupUi(self.changepassword)
        self.changepassword.show()

    def info3(self):
        self.forgottpassword = QtGui.QWizardPage()
        self.ui = Ui_forgottpassword()
        self.ui.setupUi(self.forgottpassword)
        self.forgottpassword.show()

    def info4(self):
        self.Form = QtGui.QWidget()
        self.ui = Ui_Form()
        self.ui.setupUi(self.Form)
        self.Form.show()

    def info7(self):
        self.userquestion = QtGui.QWidget()
        self.ui = Ui_userquestion()
        self.ui.setupUi(self.userquestion)
        self.userquestion.show()



if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    loginpage = QtGui.QWizardPage()
    ui = Ui_loginpage()
    ui.setupUi(loginpage)
    loginpage.show()
    sys.exit(app.exec_())

