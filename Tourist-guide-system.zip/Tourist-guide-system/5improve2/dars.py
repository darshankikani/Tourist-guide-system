# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'dars.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_descri(object):
    def setupUi(self, descri):
        ##
        db=sqlite3.connect('dummyy.db')
        cursor=db.cursor()
        row= cursor.execute('''SELECT Name FROM helpp''').fetchall()
        a=row[0][0]
        print(a)
        cursor.execute(' DELETE FROM helpp')
        db.commit()
        db.close()
 
        ##
        descri.setObjectName(_fromUtf8("descri"))
        descri.resize(570, 328)
        self.lastname = QtGui.QLabel(descri)
        self.lastname.setGeometry(QtCore.QRect(60, 40, 101, 21))
        self.lastname.setObjectName(_fromUtf8("lastname"))
        self.lastaddress = QtGui.QLabel(descri)
        self.lastaddress.setGeometry(QtCore.QRect(60, 80, 61, 21))
        self.lastaddress.setObjectName(_fromUtf8("lastaddress"))
        self.lastarea = QtGui.QLabel(descri)
        self.lastarea.setGeometry(QtCore.QRect(60, 150, 61, 21))
        self.lastarea.setObjectName(_fromUtf8("lastarea"))
        self.lasttag = QtGui.QLabel(descri)
        self.lasttag.setGeometry(QtCore.QRect(60, 200, 101, 21))
        self.lasttag.setObjectName(_fromUtf8("lasttag"))
        self.lastdescription = QtGui.QLabel(descri)
        self.lastdescription.setGeometry(QtCore.QRect(60, 240, 101, 21))
        self.lastdescription.setObjectName(_fromUtf8("lastdescription"))
        self.lastline1 = QtGui.QLineEdit(descri)
        self.lastline1.setGeometry(QtCore.QRect(140, 40, 261, 20))
        self.lastline1.setObjectName(_fromUtf8("lastline1"))
        ##
        if(a=='goa'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin  WHERE Tags='beach' ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]

        if(a=='kufri'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin WHERE Tags='hill station' ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]

        if(a=='yumthang valley'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin WHERE Tags='landscape' ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]

        if(a=='indian museum'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin WHERE Tags='museum' ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]
            
        if(a=='meenakshi'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin WHERE Tags='temple' ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]
        if(a=='gobindgarh'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin WHERE Tags='fort' ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]

        if(a=='bir billing'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin  WHERE Tags='adventureplace' ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]

        if(a=='esselworld'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin WHERE Tags='waterpark'  ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]

        if(a=='dudhsagar'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin WHERE Tags='waterfall'  ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]

        if(a=='indiannavalaviaionmuseum'):
            db=sqlite3.connect('place.db')
            cursor=db.cursor()
            row= cursor.execute('''SELECT Name,Address,Area,Tags,Descripation FROM admin  WHERE Tags='amuseum' ''').fetchall()
            dd=row[0][0]
            dd2=row[0][1]
            dd3=row[0][2]
            dd4=row[0][3]
            dd5=row[0][4]


        self.lastline1.setText(dd)

        ##
        self.lastline2 = QtGui.QLineEdit(descri)
        self.lastline2.setGeometry(QtCore.QRect(140, 80, 301, 41))
        self.lastline2.setObjectName(_fromUtf8("lastline2"))
        ##
        self.lastline2.setText(dd2)
        ##
        self.lastline3 = QtGui.QLineEdit(descri)
        self.lastline3.setGeometry(QtCore.QRect(140, 150, 261, 20))
        self.lastline3.setObjectName(_fromUtf8("lastline3"))
        ##
        self.lastline3.setText(dd3)
        ##
        self.lastline4 = QtGui.QLineEdit(descri)
        self.lastline4.setGeometry(QtCore.QRect(140, 200, 261, 20))
        self.lastline4.setObjectName(_fromUtf8("lastline4"))
        ##
        self.lastline4.setText(dd4)
        ##
        self.lastline5 = QtGui.QLineEdit(descri)
        self.lastline5.setGeometry(QtCore.QRect(150, 240, 261, 20))
        self.lastline5.setObjectName(_fromUtf8("lastline5"))
        ##
        self.lastline5.setText(dd5)
        ##
        self.retranslateUi(descri)
        QtCore.QMetaObject.connectSlotsByName(descri)

    def retranslateUi(self, descri):
        descri.setWindowTitle(_translate("descri", "Description", None))
        self.lastname.setText(_translate("descri", "NAME:", None))
        self.lastaddress.setText(_translate("descri", "ADDRESS:", None))
        self.lastarea.setText(_translate("descri", "AREA:", None))
        self.lasttag.setText(_translate("descri", "TAGS:", None))
        self.lastdescription.setText(_translate("descri", "DESCRIPATION:", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    descri = QtGui.QWidget()
    ui = Ui_descri()
    ui.setupUi(descri)
    descri.show()
    sys.exit(app.exec_())

